import stiat from './stiat.js';

m.mount(document.getElementById('dashboard'), stiat);
