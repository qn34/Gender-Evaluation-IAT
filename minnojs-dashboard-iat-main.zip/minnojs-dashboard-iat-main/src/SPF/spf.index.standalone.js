import spf from './spf.js';

m.mount(document.getElementById('dashboard'), spf);
