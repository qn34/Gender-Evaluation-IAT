import ep from './ep.js';

m.mount(document.getElementById('dashboard'), ep);
