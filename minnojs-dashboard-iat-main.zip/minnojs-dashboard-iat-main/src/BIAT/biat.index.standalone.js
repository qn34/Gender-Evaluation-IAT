import biat from './biat.js';

m.mount(document.getElementById('dashboard'), biat);
