import iat from './iat.js';

m.mount(document.getElementById('dashboard'), iat);
