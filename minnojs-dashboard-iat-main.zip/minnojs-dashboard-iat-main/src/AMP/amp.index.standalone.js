import amp from './amp.js';

m.mount(document.getElementById('dashboard'), amp);
