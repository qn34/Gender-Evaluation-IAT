## MinnoJS implicit measures wizard

This website helps you create scripts for implicit measures implemented in MinnoJS. MinnoJS is a JavaScript player for online studies, created by [Project Implicit](https://www.projectimplicit.net/). We run those scripts in Open Minno Suite, our platform for running web studies. You can install that platform on your own server, use a more simple php server for Minno, or run the script directly from Qualtrics. To learn more, you can visit our [documentation website](https://minnojs.github.io/docsite/).

See it in action [here](https://minnojs.github.io/minnojs-dashboard-iat/main_page.html).



